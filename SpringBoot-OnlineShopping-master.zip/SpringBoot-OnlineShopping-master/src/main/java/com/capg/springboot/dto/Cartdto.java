package com.capg.springboot.dto;
//Used for data transfer
public class Cartdto {
	private String cartId;

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
}
