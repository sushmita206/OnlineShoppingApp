package com.capg.springboot.Exceptions;

public class AddressNotFoundException extends Exception {
	public AddressNotFoundException(String s) {
		super(s);
	}
}
